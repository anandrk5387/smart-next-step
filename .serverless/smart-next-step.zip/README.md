# smart-next-step
A "Smart Next-Step" recommendation system — an AI-powered service that analyses customer behaviour patterns and recommends the most likely next legal or accounting action
